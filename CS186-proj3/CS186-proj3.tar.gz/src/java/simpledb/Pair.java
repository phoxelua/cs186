package simpledb;

class Pair {

    public int first, rest; //yeah, yeah it should be private- too lazy to do getters / setters

    public Pair(int x, int y){
        this.first = x;
        this.rest = y;
    }

}